#!/bin/bash
/home/cui/project/oranges/test/bochs-2.4/bochs -f bochsrc-2.4
