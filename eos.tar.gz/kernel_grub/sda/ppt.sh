#!/bin/bash
xxd -g 1 -s 0x1be -l 0x40 $1
echo $0
