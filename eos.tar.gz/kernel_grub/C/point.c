#include	<stdio.h> 
int a=1;
int *pa=&a;
int **ppa=&pa;
int ***pppa=&ppa;
int ****ppppa=&pppa;
int *****pppppa=&ppppa;
int ******ppppppa=&pppppa;
int main()
	{
    printf("%u\n",******ppppppa);
	}
