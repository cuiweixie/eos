/*
 * =====================================================================================
 *
 *       Filename:  sched.h
 *
 *    Description: process management  
 *
 *        Version:  1.0
 *        Created:  2012年01月23日 20时21分26秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Xie (), cuiweixie@gmail.com
 *        Company:  
 *
 * =====================================================================================
 */

#ifndef _SCHED_H_
#define _SCHED_H_
#include <type.h>
#define pu8(p) ((u8*)(p))
#define pu16(p) ((u16*)(p))
#define pu32(p) ((u32*)(p))
#define lgdt(p) asm("lgdtl (%%eax)"::"a"(p))
#define sgdt(p) asm("sgdtl (%%eax)"::"a"(p))
#define lidt(p) asm("lidtl (%%eax)"::"a"(p))
#define sidt(p) asm("sidtl (%%eax)"::"a"(p))
#define lldt(p) asm("lldt %%ax"::"a"(p))
#define sldt(p) asm("sldt (%%eax)"::"a"(p))
#define ltr(selector) asm("ltr %%ax"::"a"(selector))
#define str(selector) asm("str %%ax"::"a"(selector))
#define set_page_dir(p) asm("movl %%eax,%%cr3"::"a"(p))
#define lsl(selector)  asm("lsl %%eax,%1":"=a":"m"(selector))
#define switch_to_user(cs,eip,ss,esp) \
	asm("clts;\
			pushl %0;\
			pushl %1;\
			pushfl;\
			pushl %2;\
			pushl %3;\
			iret"::"a"(ss),"b"(esp),"c"(cs),"d"(eip))
#define set_esp(esp) asm("mov %0,%%esp"::"a"(esp))
#define set_ebp(esp) asm("mov %0,%%ebp"::"a"(ebp))

#define set_dpl(desc,dpl) ({u8*p=(((u8*)(&desc))+5) ;*p|=(dpl<<5);})
#define __set_gate(gate,selector,offset,attr) asm("movw %%bx,(%%eax);\
			add $2,%%eax;\
			movw %%cx,(%%eax);\
			add $2,%%eax;\
			movw %%dx,(%%eax);\
			add $2,%%eax;\
			shr $16,%%ebx;\
			movw %%bx,(%%eax)"::"a"(&gate),"b"(offset),"c"(selector),"d"(attr))
	#define set_intr_gate(n,func) __set_gate(idt[n],0x08,func,0x8e00)
#define set_trap_gate(n,func) __set_gate(idt[n],0x08,func,0x8f00)
#define set_irq_handler(n,handler) ({ idt[n].offset_l=handler,\
		idt[n].offset_h=(handler>>16);})

#define __set_desc(gdt,base,limit,attr) asm("cli;\
		      movw %%cx,(%%eax);\
		      add $2,%%eax;\
		      movw %%bx,(%%eax);\
		      add $2,%%eax;\
		      shr $16,%%ebx;\
		      movb %%bl,(%%eax);\
		      add $1,%%eax;\
					movw %%dx,(%%eax);\
					add $2,%%eax;\
					movb %%bh,(%%eax);\
					sti"\
					::"a"(&gdt),"b"(base),"c"(limit),"d"((attr)&0xf0ff|(((limit)&0xf0000)>>8)))
#define set_ldt_seg(n,base) __set_desc(gdt[n],(u32)base,0xfffff,0xc0e2)
#define set_tss_seg(n,base) __set_desc(gdt[n],(u32)base,104,0x00e9)
#define set_desc_base(desc,base) ({\
		u16 *p=&(desc);\
		*p=base&0xffff;\
		p+=2;\
		*((u8*)p)=(((base)>>16)&0xff);\
		p++;\
		*((u8*)p)=(((base)>>24)&0xff);\
   })

 struct descriptor{
  u16 limit_l;
	u16 base_l;
	u16 word3;
	u16 word4;
} __attribute__ ((aligned(8)));

struct tss{
	u32 ex_tss;
	u32 esp0,ss0,esp1,ss1,esp2,ss2;
	u32 cr3,eip,eflags,eax,ecx,edx,ebx,esp,ebp,esi,edi;
	u32 es,cs,ss,ds,fs,gs,ldt,iopl;
} __attribute__ ((aligned(4)));
struct gate{
	u16 offset_l;
  u16 selector;
	u16 attr;
	u16 offset_h;
} __attribute__ ((aligned(8)));
#define TASK_RUNNING 0
#define TASK_INTERRUPTIBLE 2
#define TASK_UNINTERRUPTIBLE 4
#define TASK_STOP    8
#define GDT_SIZE 255
#define IDT_SIZE 255
extern u8 gdt_ptr[6];
extern struct descriptor gdt[GDT_SIZE],ldt0[3],ldt1[3];
extern struct tss tss0,tss1;
extern u8 gdt_ptr[6];
extern u8 idt_ptr[8];
extern struct gate idt[IDT_SIZE];
extern void asm_general_handler();
#define STACK_SIZE 1024
struct task_struct {
u32 pid;
u32 n_gdt;
u32 state;
u32 slice_used;
u32 slice_left;
u32 priority;
u32 signal;
u16 tss_selector;
struct tss tss;
u16 ldt_selector;
struct descriptor ldt[4];
u8 kernel_stack[STACK_SIZE];
u8 user_stack[STACK_SIZE];
};
#define FIRST_TSS_ENTRY  5
#define FIRST_LDT_ENTRY  4
#define __TSS(n) ((((u32)n)<<4)+(FIRST_TSS_ENTRY<<3))
#define __LDT(n) ((((u32)n)<<4)+(FIRST_LDT_ENTRY<<3))
#define MAX_PROC 128
extern u32 current;
struct task_struct process[MAX_PROC];
#define sti() asm("sti")
#define cli() asm("cli")
#define switch_to(n) ({\
		    struct { long a,b;}__tmp;\
				asm("mov %%dx,%1\n"\
					"ljmp *%0"\
					::"m"(*&__tmp.a),"m"(*&__tmp.b),"d"(__TSS(n)));\
		})
#define LOCK_INC(a,i) asm("lock;add %1,%0"::"m"(a),"i"(i))
#endif
