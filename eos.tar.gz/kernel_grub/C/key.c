#include <stdio.h>
#include	<stdlib.h>

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  main
 *  Description:  
 * =====================================================================================
 */
int main ( int argc, char *argv[] )
{
	long unsigned long int a=1,b;
	a=a<<32;
	b=a>>32;
  printf("%d %d\n",a,b);
	return EXIT_SUCCESS;
}				/* ----------  end of function main  ---------- */
