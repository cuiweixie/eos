#include	<stdio.h>
int main ( int argc, char *argv[] )
{
  unsigned char a=0xf,b=0xf0;
	unsigned short int c;
	c=a|(b<<8);
	printf("%x\n",c);
}
