#include <stdio.h>
#include	<stdlib.h>

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  main
 *  Description:  
 * =====================================================================================
 */
#define div(a,b) ({\
		unsigned int *p=&a;unsigned int l=*p/b,h=*(p+1)/b;\
		unsigned long long int ret=(unsigned long long int)h<<32|l;\
		ret;\
		})
#define rem(a,b) ({\
unsigned int *p=&a;unsigned int l=*p%b,h=*(p+1)%b;\
		unsigned int ret=0xffffffff;ret=ret%b;ret=(ret+1)*h+l;ret%=b;\
		ret;\
		})

int main ( int argc, char *argv[] )
{
  int ***p=0xff;	
	unsigned long long int a=1;a=a<<32;a+=6;
	unsigned int b=rem(a,10);
	printf("%d",b);
}				/* ----------  end of function main  ---------- */
