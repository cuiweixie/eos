#include	<stdlib.h>
#include	<stdio.h>
#define   u16 unsigned short int
#define u8 unsigned char 
struct descriptor{
	u16 limit_l;
	u16 base_l;
	u16 base_m:8;
	u16 type:4;
	u16 s:1;
	u16 dpl:2;
	u16 p:1;
	u16 limit_h:4;
	u16 attr_h:4;
	u16 base_h:8;
};
struct descriptor2{
	u16 limit_l;
	u16 base_l;
	u16 word3;
	u16 word4;
} __attribute__ ((aligned(8)));
struct descriptor desc;
int main ( int argc, char *argv[] )
{
   printf("%u\n",sizeof(desc));
	printf("%x\n",(unsigned int)&desc);
	 printf("%x\n",desc.dpl);
	 printf("%x\n",desc.p);

	 desc.dpl=0xff;
	 printf("%x\n",desc.dpl);
	 printf("%x\n",desc.p);
  
}
