#!/bin/bash - 
#===============================================================================
#
#          FILE:  code_line.sh
# 
#         USAGE:  ./code_line.sh 
# 
#   DESCRIPTION:  
# 
#       OPTIONS:  ---
#  REQUIREMENTS:  ---
#          BUGS:  ---
#         NOTES:  ---
#        AUTHOR: YOUR NAME (), 
#       COMPANY: 
#       CREATED: 2012年02月04日 20时14分16秒 CST
#      REVISION:  ---
#===============================================================================

set -o nounset                              # Treat unset variables as an error

j="";
for file in $(find . -iregex '.*\.[chm]') 
do
	if [ -f $file ];
	then
		j+=" "$file;
	fi
done
wc -l $j
j="";

